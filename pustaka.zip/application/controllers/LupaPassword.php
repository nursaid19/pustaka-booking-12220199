<?php 
class LupaPassword extends CI_Controller 
{ 
    public function index() 
    {
        $this->load->view('autentifikasi/lupaPassword');
     }
}
?>